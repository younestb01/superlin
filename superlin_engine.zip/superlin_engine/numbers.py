"""Parsing of Algerian-style amounts: '1 234 567,89', '1.234.567,89', '1234.5'."""
import re
from decimal import Decimal, InvalidOperation

PERCENT_RE = re.compile(r"\d+(?:[.,]\d+)?\s*%")
AMOUNT_RE = re.compile(r"\d{1,3}(?:[ \u00a0.,]\d{3})+(?:[.,]\d{1,2})?(?!\d)|\d+(?:[.,]\d{1,2})?(?!\d)")

def parse_amount(token: str):
    t = token.replace("\u00a0", " ").strip()
    t = t.replace(" ", "")
    if not t or not re.fullmatch(r"[\d.,]+", t):
        return None
    if "," in t and "." in t:
        dec = "," if t.rfind(",") > t.rfind(".") else "."
        thou = "." if dec == "," else ","
        t = t.replace(thou, "").replace(dec, ".")
    elif "," in t or "." in t:
        sep = "," if "," in t else "."
        parts = t.split(sep)
        if len(parts) > 2 or len(parts[-1]) == 3:   # thousands separator(s) only
            t = "".join(parts)
        else:
            t = parts[0] + "." + parts[1]
    try:
        return Decimal(t).quantize(Decimal("0.01"))
    except InvalidOperation:
        return None

def find_amounts(text: str):
    """Amounts in text (percentages removed). Returns list of (Decimal, raw)."""
    clean = PERCENT_RE.sub(" ", text)
    out = []
    for m in AMOUNT_RE.finditer(clean):
        v = parse_amount(m.group(0))
        if v is not None:
            out.append((v, m.group(0).strip()))
    return out
