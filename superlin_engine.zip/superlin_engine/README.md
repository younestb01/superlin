# SUPERLIN engine

## تشغيل محلي
```bash
python -m venv venv && source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python -m superlin_engine.cli invoice.jpg --kind purchase --own-nif <NIF شركتك>   # اختبار بدون خادم
uvicorn superlin_engine.server:app --host 0.0.0.0 --port 8000                      # تشغيل الخادم
```
التوثيق التفاعلي: http://127.0.0.1:8000/docs

## تشغيل على Colab مع Cloudflare tunnel
```python
!pip install paddlepaddle-gpu paddleocr fastapi "uvicorn[standard]" python-multipart
# ارفع مجلد superlin_engine إلى /content ثم:
import subprocess, os
os.environ["SUPERLIN_API_KEY"] = "غيّر-هذا-المفتاح"
subprocess.Popen(["uvicorn", "superlin_engine.server:app", "--port", "8000"])
!wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O cf && chmod +x cf
!./cf tunnel --url http://localhost:8000      # انسخ رابط trycloudflare.com
```
ضع الرابط في `EngineService(baseUrl: ..., apiKey: ...)`.

## الاختبارات
```bash
python superlin_engine/tests/test_engine.py
python superlin_engine/tests/test_server.py
```
