"""Quick local test:
   python -m superlin_engine.cli invoice.jpg --kind purchase --own-nif 000123456789012
   add --dump to print what the OCR read, line by line (useful to debug a missing field)."""
import argparse, json
from .ocr_engine import run_ocr
from .layout import group_lines, line_text
from .extractor import extract_invoice
from .reconcile import reconcile, fiscal_warnings
from .server import invoice_to_dict

ap = argparse.ArgumentParser()
ap.add_argument("image"); ap.add_argument("--kind", default="unknown")
ap.add_argument("--own-nif"); ap.add_argument("--own-name"); ap.add_argument("--month")
ap.add_argument("--dump", action="store_true", help="print OCR text lines with positions")
a = ap.parse_args()

boxes = run_ocr(a.image)
if a.dump:
    for ln in group_lines(boxes):
        print(f"y={int(ln[0].yc):5d} | " + " | ".join(f"{b.text} ({b.conf:.2f})" for b in ln))
    print("-" * 60)
inv = reconcile(extract_invoice(boxes, a.kind, a.own_nif, a.own_name))
out = invoice_to_dict(inv); out["warnings"] = fiscal_warnings(inv, a.month)
print(json.dumps(out, ensure_ascii=False, indent=2))
