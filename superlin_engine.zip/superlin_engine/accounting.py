"""Accounting entries (SCF) and monthly G50 VAT summary.

Account numbers are DEFAULTS per company and must be confirmed with the accountant
(set them when the company account is created).
"""
from __future__ import annotations
from decimal import Decimal as D
from .schema import Invoice

DEFAULT_ACCOUNTS = {
    "purchase_expense": "600",   # achats de marchandises
    "supplier": "401",
    "vat_deductible": "4456",
    "purchase_timbre": "645",    # TO CONFIRM
    "sales_revenue": "700",      # ventes de marchandises
    "customer": "411",
    "vat_collected": "4457",
    "sales_timbre": "447",       # TO CONFIRM
}

def make_entry(inv: Invoice, accounts: dict | None = None) -> list[dict]:
    a = {**DEFAULT_ACCOUNTS, **(accounts or {})}
    lbl = f"Facture {inv.number or '?'} {inv.counterparty_name or ''}".strip()
    rows = []
    def add(acc, debit=D(0), credit=D(0)):
        if debit or credit: rows.append({"account": acc, "debit": debit, "credit": credit, "label": lbl})
    timbre, net = inv.val("timbre"), inv.val("net_a_payer")
    if inv.kind == "purchase":
        add(a["purchase_expense"], debit=inv.val("total_ht"))
        add(a["vat_deductible"], debit=inv.val("total_tva"))
        add(a["purchase_timbre"], debit=timbre)
        add(a["supplier"], credit=net)
    elif inv.kind == "sales":
        ht = inv.val("ht19") + inv.val("ht9") + inv.val("ht_exonere")
        tva = inv.val("tva19") + inv.val("tva9")
        add(a["customer"], debit=net)
        add(a["sales_revenue"], credit=ht)
        add(a["vat_collected"], credit=tva)
        add(a["sales_timbre"], credit=timbre)
    else:
        raise ValueError("invoice kind must be 'purchase' or 'sales'")
    d = sum(r["debit"] for r in rows); c = sum(r["credit"] for r in rows)
    if abs(d - c) > D("1.01"):
        raise ValueError(f"unbalanced entry: debit {d} != credit {c}")
    return rows

def g50_summary(invoices: list[Invoice]) -> dict:
    s = {k: D(0) for k in ("sales_ht19", "sales_tva19", "sales_ht9", "sales_tva9",
                           "sales_ht_exonere", "sales_timbre", "purchase_ht",
                           "purchase_tva_deductible")}
    for inv in invoices:
        if inv.kind == "sales":
            s["sales_ht19"] += inv.val("ht19");  s["sales_tva19"] += inv.val("tva19")
            s["sales_ht9"] += inv.val("ht9");    s["sales_tva9"] += inv.val("tva9")
            s["sales_ht_exonere"] += inv.val("ht_exonere"); s["sales_timbre"] += inv.val("timbre")
        elif inv.kind == "purchase":
            s["purchase_ht"] += inv.val("total_ht")
            s["purchase_tva_deductible"] += inv.val("total_tva")
    collected = s["sales_tva19"] + s["sales_tva9"]
    s["tva_collected"] = collected
    net = collected - s["purchase_tva_deductible"]
    s["tva_to_pay"] = max(net, D(0))
    s["tva_credit_carry"] = max(-net, D(0))
    return s
