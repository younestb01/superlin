"""Group OCR boxes into visual lines (so 'Total HT .... 12 000,00' is one line)."""
from .schema import Box

def group_lines(boxes: list[Box], tol: float = 0.6):
    """Boxes whose vertical centres differ by < tol * box height share a line."""
    boxes = sorted(boxes, key=lambda b: (b.yc, b.x0))
    lines: list[list[Box]] = []
    for b in boxes:
        if lines:
            ref = lines[-1]
            yc = sum(x.yc for x in ref) / len(ref)
            h = sum(x.h for x in ref) / len(ref)
            if abs(b.yc - yc) < tol * max(h, b.h):
                ref.append(b); continue
        lines.append([b])
    for ln in lines:
        ln.sort(key=lambda b: b.x0)
    return lines

def line_text(line: list[Box]) -> str:
    return " ".join(b.text for b in line)
