"""PaddleOCR wrapper -> list[Box]. Handles both PaddleOCR 2.x and 3.x result formats."""
from __future__ import annotations
import os
from .schema import Box

os.environ.setdefault("PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK", "True")   # skip slow hoster check

_ENGINE = None

def _get_engine(lang="fr"):
    global _ENGINE
    if _ENGINE is None:
        from paddleocr import PaddleOCR
        try:    # 3.x
            _ENGINE = PaddleOCR(lang=lang, enable_mkldnn=False,      # oneDNN crashes on some Windows CPUs
                                use_doc_orientation_classify=True,
                                use_doc_unwarping=False, use_textline_orientation=True)
        except TypeError:   # 2.x
            _ENGINE = PaddleOCR(lang=lang, use_angle_cls=True, show_log=False, enable_mkldnn=False)
    return _ENGINE

def run_ocr(image_path: str, lang: str = "fr") -> list[Box]:
    eng = _get_engine(lang)
    boxes: list[Box] = []
    if hasattr(eng, "predict"):               # 3.x
        for res in eng.predict(image_path):
            r = res.json["res"] if hasattr(res, "json") else res
            for text, conf, poly in zip(r["rec_texts"], r["rec_scores"], r["rec_polys"]):
                xs = [p[0] for p in poly]; ys = [p[1] for p in poly]
                boxes.append(Box(text, float(conf), min(xs), min(ys), max(xs), max(ys)))
    else:                                     # 2.x
        result = eng.ocr(image_path, cls=True)
        for line in (result[0] or []):
            poly, (text, conf) = line
            xs = [p[0] for p in poly]; ys = [p[1] for p in poly]
            boxes.append(Box(text, float(conf), min(xs), min(ys), max(xs), max(ys)))
    return boxes
