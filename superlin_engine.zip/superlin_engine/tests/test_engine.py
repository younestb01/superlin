import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from decimal import Decimal as D
from superlin_engine.schema import Box
from superlin_engine.extractor import extract_invoice
from superlin_engine.reconcile import reconcile, fiscal_warnings
from superlin_engine.accounting import make_entry, g50_summary

def boxes(rows):
    """rows: list of lists of strings; each row becomes boxes on one visual line."""
    out = []
    for i, row in enumerate(rows):
        for j, t in enumerate(row):
            out.append(Box(t, 0.95, 50 + j * 300, 40 + i * 40, 250 + j * 300, 70 + i * 40))
    return out

PURCHASE = [
    ["SARL EL AMANA", "FACTURE N° FA-2026/0123"],
    ["Date : 12/10/2026", "N.I.F : 099 916 000 123 456"],
    ["N.I.S : 099 916 000 123 4", "Client : ETS TEST"],
    ["N.I.F : 000 123 456 789 012"],
    ["Désignation", "Qté", "Montant HT"],
    ["Total HT", "100 000,00"],
    ["HT exonéré", "10 000,00"],
    ["Total TVA", "17 100,00"],
    ["Total TTC", "117 100,00"],
    ["Timbre fiscal", "1 171,00"],
    ["Net à payer", "118 271,00"],
]
def run_purchase(rows):
    return reconcile(extract_invoice(boxes(rows), "purchase", own_nif="000123456789012"))

def test_clean_purchase():
    inv = run_purchase(PURCHASE)
    assert inv.status == "ok", inv.notes
    assert inv.date == "2026-10-12" and inv.number == "FA-2026/0123"
    assert inv.counterparty_nif == "099916000123456"
    assert inv.val("total_ht") == D("100000.00") and inv.val("net_a_payer") == D("118271.00")
    assert fiscal_warnings(inv, "2026-10") == []

def test_ocr_digit_error_is_repaired():
    rows = [r[:] for r in PURCHASE]
    rows[7] = ["Total TVA", "17 100,00"]; rows[8] = ["Total TTC", "117 100,00"]
    rows[5] = ["Total HT", "108 000,00"]       # 0 -> 8 style error on HT
    inv = run_purchase(rows)
    assert inv.val("total_ht") == D("100000.00")
    assert inv.status == "corrected"

def test_missing_net_is_derived():
    inv = run_purchase([r for r in PURCHASE if r[0] != "Net à payer"])
    assert inv.val("net_a_payer") == D("118271.00") and inv.status == "ok"   # TTC verified by HT+TVA
    assert any("net_a_payer derived" in n for n in inv.notes)

SALES = [
    ["SARL NOTRE SOCIETE", "FACTURE N° 2026/045"],
    ["N.I.F : 000123456789012", "Date : 03/11/2026"],
    ["Client : SPA CLIENT", "N.I.F : 099 916 000 999 888"],
    ["Total HT 19%", "50 000,00"],
    ["TVA 19%", "9 500,00"],
    ["Total HT 9%", "20 000,00"],
    ["TVA 9%", "1 800,00"],
    ["HT exonéré", "5 000,00"],
    ["Total TTC", "86 300,00"],
    ["Net à payer", "86 300,00"],
]
def test_sales_split():
    inv = reconcile(extract_invoice(boxes(SALES), "sales", own_nif="000123456789012"))
    assert inv.status == "ok", inv.notes
    assert inv.val("ht19") == D("50000.00") and inv.val("tva9") == D("1800.00")
    assert inv.counterparty_nif == "099916000999888"
    entry = make_entry(inv)
    assert sum(r["debit"] for r in entry) == sum(r["credit"] for r in entry)

def test_rate_table_rows_and_autodetect():
    rows = [r[:] for r in SALES[:3]] + [["19 %", "50 000,00", "9 500,00"], ["9 %", "20 000,00", "1 800,00"],
            ["HT exonéré", "5 000,00"], ["Total TTC", "86 300,00"], ["Net à payer", "86 300,00"]]
    inv = reconcile(extract_invoice(boxes(rows), "unknown", own_nif="000123456789012"))
    assert inv.kind == "sales" and inv.status == "ok", inv.notes

def test_g50_and_purchase_entry():
    p = run_purchase(PURCHASE)
    s = reconcile(extract_invoice(boxes(SALES), "sales", own_nif="000123456789012"))
    entry = make_entry(p)
    assert sum(r["debit"] for r in entry) == D("118271.00")
    g = g50_summary([p, s])
    assert g["tva_collected"] == D("11300.00") and g["tva_credit_carry"] == D("5800.00")

HALIB = [
    ["SARL HALIB EL FEDJR EL DJADID", "FACTURE N°: 00658"],
    ["RC N°:13/00-0265080-B-16"],
    ["NIF:001613026508004 N° ART:13271004248", "Client: BEKKOUCHE MOHAMMED"],
    ["Date: 20/04/2026", "N° R.C: 13/00-1402620A20"],
    ["Réglement: ESPECE", "N.I.F: 18613270107018400000"],
    ["", "N° ART: 13330115202"],
    ["Reference", "Désignation", "Un", "Tva %", "Quantité", "Prix H.T", "Montant H.T"],
    ["20", "LBEN EN SACHET 1 LITRE", "L", "19.00", "1235", "54.62", "67 455.70"],
    ["30", "BEURRE", "KG", "19.00", "10", "500.00", "5 000.00"],
    ["Taux", "Base", "Montant TVA"],
    ["19.00", "73 312.84", "13 929.44", "Total HT", "73 312.84"],
    ["Total TVA", "13 929.44"],
    ["Timbre Fiscal", "1 309.00"],
    ["Net a payer", "88 551.28"],
]
def test_real_invoice_halib():
    inv = reconcile(extract_invoice(boxes(HALIB), "purchase", own_nif="18613270107018400000"))
    assert inv.status == "ok", inv.notes
    assert inv.counterparty_nif == "001613026508004" and inv.counterparty_art == "13271004248"
    assert inv.val("ttc") == D("87242.28") and inv.val("net_a_payer") == D("88551.28")
    assert inv.counterparty_name == "SARL HALIB EL FEDJR EL DJADID"

def test_sales_client_name_and_art():
    inv = reconcile(extract_invoice(boxes(HALIB), "sales", own_nif="001613026508004"))
    assert inv.counterparty_nif == "18613270107018400000"
    assert inv.counterparty_art == "13330115202" and inv.counterparty_name == "BEKKOUCHE MOHAMMED"

FARMING = [
    ["Page 1 / 1"],
    ["N° Article d'Imposition :", "13271006370"],
    ["N° Immatriculation Fiscale :", "002313026587438"],
    ["N° Registre de Commerce :", "23B0265874-00/13"],
    ["N° Identification Statistique :", "002313270002858"],
    ["Farming Pro"],
    ["SARL"],
    ["MAGHNIA, le 05/09/2026"],
    ["Facture"],
    ["N° 190/26"],
    ["Code Client :", "S DIST"],
    ["Client :", "EURL S DIST TRADE", "N° Art. Imp :", "16560204021"],
    ["Activité :", "DISTRIBUTION", "Imm. Fisc :", "002416102020257"],
    ["Ville :", "ALGER", "NIS :", "002416560153935"],
    ["N°", "Réf", "Article", "% TVA", "Montant TVA", "Prix U. (HT)", "Qte", "Montant (HT)"],
    ["1", "AMIDON EG_", "AMIDON DE MAIS", "9", "189 000.00", "84.00", "25 000", "2 100 000.00"],
    ["2", "CACAO NE", "POUDRE DE CACAO", "19", "622 690.80", "1 092.44", "3 000", "3 277 320.00"],
    ["TVA %", "Total TVA", "Total HT", "Total HT", "5 377 320.00 DA"],
    ["9", "189 000.00", "2 100 000.00", "Total TVA", "811 690.80 DA"],
    ["19", "622 690.80", "3 277 320.00", "Timbre", "0.00 DA"],
    ["", "", "", "Total TTC", "6 189 010.80 DA"],
    ["Arrêtée la présente Facture, à la somme de :"],
]
def test_real_invoice_farming_pro():
    inv = reconcile(extract_invoice(boxes(FARMING), "purchase", own_nif="002416102020257"))
    assert inv.status == "ok", inv.notes
    assert inv.number == "190/26" and inv.date == "2026-09-05"
    assert inv.counterparty_nif == "002313026587438"
    assert inv.counterparty_nis == "002313270002858" and inv.counterparty_art == "13271006370"
    assert inv.counterparty_name == "Farming Pro SARL"
    assert inv.val("total_ht") == D("5377320.00") and inv.val("total_tva") == D("811690.80")
    assert inv.val("ht9") == D("2100000.00") and inv.val("tva9") == D("189000.00")
    assert inv.val("ht19") == D("3277320.00") and inv.val("tva19") == D("622690.80")
    assert inv.val("ttc") == D("6189010.80") and inv.val("net_a_payer") == D("6189010.80")

def test_real_invoice_farming_pro_as_sales():
    inv = reconcile(extract_invoice(boxes(FARMING), "sales", own_nif="002313026587438"))
    assert inv.status == "ok", inv.notes
    assert inv.counterparty_nif == "002416102020257" and inv.counterparty_name == "EURL S DIST TRADE"
    assert inv.counterparty_nis == "002416560153935" and inv.counterparty_art == "16560204021"
    assert make_entry(inv)

def hb(text, y, x=20, h=25, w=None):
    return Box(text, 0.97, x, y, x + (w or 8 * len(text)), y + h)

def test_cma_cgm_screenshot():
    bx = [hb("CMACGM ALGERIE - Consignations de Navires et de Cargaison", 20, h=40),
          hb("IMMEUBLE ENTREPRISE PORTUAIRE GHAZAOUET", 70),
          hb("Capital: 207 000 000 DA NIF:099916000895666/ NIS: 099716019873601 RC:99B0008956 Al:13070053072", 110),
          hb("FACTURE N°:", 160, h=35), hb("DZIM2029053", 160, x=400, h=35),
          hb("Date", 200), hb("15/08/2026", 200, x=120),
          hb("Client : 0007567269", 220),
          hb("Client:", 240), hb("SARL FARMING PRO", 240, x=120),
          hb("NIF: 002313026587438 / 00000 NIS : 002313270002858", 280),
          hb("Mont. HT (DA)=", 400, x=300), hb("304 268,40", 400, x=600),
          hb("Mont.TVA (DA)=", 440, x=300), hb("57 621,00", 440, x=600),
          hb("Mont.TTC(DA)=", 480, x=300), hb("361 889,40", 480, x=600)]
    inv = reconcile(extract_invoice(bx, "purchase", own_nif="002313026587438"))
    assert inv.status == "ok", inv.notes
    assert inv.number == "DZIM2029053" and inv.date == "2026-08-15"
    assert inv.counterparty_nif == "099916000895666" and inv.counterparty_nis == "099716019873601"
    assert inv.counterparty_art == "13070053072"
    assert inv.counterparty_name.startswith("CMACGM ALGERIE")     # not the 'IMMEUBLE ENTREPRISE...' address
    assert inv.val("ttc") == D("361889.40")
    assert any("not subject to TVA" in w and "1000" in w for w in fiscal_warnings(inv, "2026-08")), fiscal_warnings(inv)

if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"): f(); print("PASS", n)
