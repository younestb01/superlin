import sys, os, io
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from fastapi.testclient import TestClient
from superlin_engine import server, ocr_engine
from superlin_engine.tests.test_engine import boxes, PURCHASE, SALES

def test_api_flow():
    ocr_engine.run_ocr = lambda p, lang="fr": boxes(PURCHASE)       # fake OCR, no Paddle needed
    c = TestClient(server.app)
    r = c.post("/extract", files={"file": ("a.jpg", io.BytesIO(b"x"), "image/jpeg")},
               data={"kind": "purchase", "own_nif": "000123456789012", "month": "2026-10"})
    assert r.status_code == 200, r.text
    j = r.json(); assert j["status"] == "ok" and j["amounts"]["net_a_payer"]["value"] == "118271.00"
    e = c.post("/entry", json={"invoice": j}); assert e.status_code == 200
    assert round(sum(float(x["debit"]) for x in e.json()), 2) == 118271.00
    ocr_engine.run_ocr = lambda p, lang="fr": boxes(SALES)
    s = c.post("/extract", files={"file": ("b.jpg", io.BytesIO(b"x"), "image/jpeg")},
               data={"kind": "sales", "own_nif": "000123456789012"}).json()
    g = c.post("/g50", json={"invoices": [j, s]}).json()
    assert g["tva_collected"] == "11300.00", g
    assert c.post("/extract", files={"file": ("a.jpg", io.BytesIO(b"x"))}, data={"kind": "zzz"}).status_code == 400

if __name__ == "__main__":
    test_api_flow(); print("PASS test_api_flow")
