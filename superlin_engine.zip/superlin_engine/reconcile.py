"""Fiscal consistency checks + self-repair of OCR digit errors.

All checks are linear equations over named amounts. Conventions (edit in one place):
  - purchase: total_ht includes the VAT-exempt part (ht_exonere); TTC = total_ht + total_tva
  - sales:    TTC = ht19 + ht9 + ht_exonere + tva19 + tva9
  - net_a_payer = TTC + timbre
"""
from __future__ import annotations
from decimal import Decimal as D
from .schema import Invoice, Amount

TOL = D("1.01")            # rounding tolerance in DZD
RATES = {"19": D("0.19"), "9": D("0.09")}
CONFUSIONS = {"0": "68", "1": "7", "3": "8", "5": "6", "6": "05", "7": "1", "8": "30", "9": "4"}

def equations(inv: Invoice):
    f = inv.amounts
    eqs = []
    for r, rate in RATES.items():
        if f"ht{r}" in f and f"tva{r}" in f:
            eqs.append((f"tva{r}=ht{r}*{rate}", {f"tva{r}": D(1), f"ht{r}": -rate}))
    if inv.kind == "sales":
        eqs.append(("ttc=sum", {"ttc": D(1), "ht19": D(-1), "ht9": D(-1), "ht_exonere": D(-1),
                                "tva19": D(-1), "tva9": D(-1)}))
    else:
        eqs.append(("ttc=ht+tva", {"ttc": D(1), "total_ht": D(-1), "total_tva": D(-1)}))
        if "ht19" in f or "ht9" in f:
            eqs.append(("ht=parts", {"total_ht": D(1), "ht19": D(-1), "ht9": D(-1), "ht_exonere": D(-1)}))
            eqs.append(("tva=parts", {"total_tva": D(1), "tva19": D(-1), "tva9": D(-1)}))
    eqs.append(("net=ttc+timbre", {"net_a_payer": D(1), "ttc": D(-1), "timbre": D(-1)}))
    return eqs

def _val(inv, k):
    a = inv.amounts.get(k)
    return a.value if a else None

def _residual(inv, coefs, override=None):
    """Residual of one equation; absent optional fields count as 0. None if a core field is missing."""
    s = D(0)
    for k, c in coefs.items():
        v = override[1] if override and override[0] == k else _val(inv, k)
        if v is None:
            if k in ("ht19", "ht9", "tva19", "tva9", "ht_exonere", "timbre"): v = D(0)
            else: return None
        s += c * v
    return s

def _failing(inv, override=None):
    bad = []
    for name, coefs in equations(inv):
        r = _residual(inv, coefs, override)
        if r is not None and abs(r) > TOL: bad.append(name)
    return bad

def _solve_for(inv, coefs, target):
    c = coefs[target]
    rest = D(0)
    for k, ck in coefs.items():
        if k == target: continue
        v = _val(inv, k)
        if v is None:
            if k in ("ht19", "ht9", "tva19", "tva9", "ht_exonere", "timbre"): v = D(0)
            else: return None
        rest += ck * v
    return (-rest / c).quantize(D("0.01"))

def _variants(raw: str):
    """Single-character OCR confusions of a raw amount string."""
    for i, ch in enumerate(raw):
        for alt in CONFUSIONS.get(ch, ""):
            yield raw[:i] + alt + raw[i + 1:]

def reconcile(inv: Invoice) -> Invoice:
    from .numbers import parse_amount
    if inv.kind != "sales" and "ht_exonere" not in inv.amounts:
        inv.amounts["ht_exonere"] = Amount(D(0), "", 1.0, "default")
    if "timbre" not in inv.amounts:
        inv.amounts["timbre"] = Amount(D(0), "", 1.0, "default")

    # 1. derive one missing core field from the others
    core = ["total_ht", "total_tva", "ttc", "net_a_payer"] if inv.kind != "sales" else \
           ["ttc", "net_a_payer"]
    for _ in range(3):
        for name, coefs in equations(inv):
            missing = [k for k in coefs if k in core and _val(inv, k) is None]
            if len(missing) == 1:
                v = _solve_for(inv, coefs, missing[0])
                if v is not None and v >= 0:
                    inv.amounts[missing[0]] = Amount(v, "", 0.0, "derived")
                    inv.notes.append(f"{missing[0]} derived from {name}")

    # 2. check; 3. try a single-field repair
    bad = _failing(inv)
    if not bad:
        # status after a clean check. Derived fields are trusted only with a 2nd confirming equation;
        # a missing net_a_payer is accepted when the TTC it is built from is independently verified.
        eqs = equations(inv)
        def passes(c): return _residual(inv, c) is not None
        def derived_in(c): return any(inv.amounts[x].source == "derived" for x in c if x in inv.amounts)
        def confirmed(k):
            if sum(1 for _, c in eqs if k in c and passes(c)) >= 2: return True
            if k == "net_a_payer":
                return all(f == "net_a_payer" or f not in inv.amounts or
                           (inv.amounts[f].source != "derived" and
                            (f in ("timbre", "ht_exonere") or any(
                                f in c and not derived_in(c) and passes(c) for _, c in eqs)))
                           for _, c in eqs if "net_a_payer" in c for f in c)
            return False
        unverified = [k for k, a in inv.amounts.items() if a.source == "derived" and not confirmed(k)]
        inv.status = "corrected" if unverified else "ok"
        if unverified: inv.notes.append("derived without cross-check: " + ", ".join(unverified))
        return inv
    fixes = []
    for k, a in inv.amounts.items():
        if a.source == "derived": continue
        cands = set()
        for name, coefs in equations(inv):
            if k in coefs and name in bad:
                v = _solve_for(inv, coefs, k)
                if v is not None and v >= 0: cands.add(v)
        for cv in cands:
            if not _failing(inv, (k, cv)):
                near = a.raw and any(parse_amount(x) == cv for x in _variants(a.raw))
                fixes.append((k, cv, bool(near), a.conf))
    if fixes:
        fixes.sort(key=lambda x: (not x[2], x[3]))          # OCR-plausible first, then lowest confidence
        k, cv, near, _ = fixes[0]
        old = inv.amounts[k]
        inv.amounts[k] = Amount(cv, old.raw, old.conf, "corrected")
        inv.notes.append(f"{k} corrected {old.value} -> {cv}" + ("" if near else " (by equation only)"))
        plausible = sum(1 for f in fixes if f[2])      # fixes that match a real OCR confusion
        inv.status = "corrected" if near and plausible == 1 else "review"
        if inv.status == "review": inv.notes.append("several possible fixes; please review")
    else:
        inv.status = "review"
        inv.notes.append("inconsistent totals: " + ", ".join(bad))
    return inv

# ---- fiscal sanity checks on the header -------------------------------------
def fiscal_warnings(inv: Invoice, month: str | None = None) -> list[str]:
    w = []
    if not inv.number: w.append("invoice number missing")
    if not inv.date: w.append("date missing")
    elif month and not inv.date.startswith(month): w.append(f"date {inv.date} is outside folder {month}")
    if "ht19" not in inv.amounts and "ht9" not in inv.amounts:
        ht = inv.val("total_ht") - inv.val("ht_exonere"); tva = inv.val("total_tva")
        if ht > 0 and tva > 0 and abs(tva - ht * RATES["19"]) > D("1.5") and abs(tva - ht * RATES["9"]) > D("1.5"):
            msg = f"TVA is {tva / ht * 100:.2f}% of HT: mixed rates or part not subject to TVA"
            exo = ht - tva / RATES["19"]
            if 0 < exo < ht * D("0.2"):
                msg += f" (if the rest is at 19%, about {exo:.0f} DA is not taxed: check ht_exonere)"
            w.append(msg)
    if not inv.counterparty_nif: w.append("counterparty NIF missing")
    elif len(inv.counterparty_nif) not in (15, 20): w.append("NIF length unusual")
    return w
