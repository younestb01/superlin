from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional

@dataclass
class Box:
    """One OCR text box. x/y in pixels, origin top-left."""
    text: str
    conf: float
    x0: float
    y0: float
    x1: float
    y1: float

    @property
    def yc(self): return (self.y0 + self.y1) / 2
    @property
    def h(self): return max(self.y1 - self.y0, 1.0)

@dataclass
class Amount:
    value: Decimal
    raw: str = ""
    conf: float = 1.0
    source: str = "ocr"        # ocr | derived | default | corrected

@dataclass
class Invoice:
    kind: str = "unknown"                 # purchase | sales | unknown
    date: Optional[str] = None            # ISO yyyy-mm-dd
    number: Optional[str] = None
    counterparty_name: Optional[str] = None
    counterparty_nif: Optional[str] = None
    counterparty_nis: Optional[str] = None
    counterparty_art: Optional[str] = None   # N° ART (numéro d'article d'imposition)
    own_nif: Optional[str] = None
    amounts: dict = field(default_factory=dict)   # name -> Amount
    status: str = "review"                # ok | corrected | review
    notes: list = field(default_factory=list)

    def val(self, name, default=Decimal("0")):
        a = self.amounts.get(name)
        return a.value if a else default
