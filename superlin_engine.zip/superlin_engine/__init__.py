"""SUPERLIN invoice engine: OCR -> extraction -> reconciliation -> accounting."""
