"""Rule-based extraction of header + totals from OCR boxes (no product table)."""
from __future__ import annotations
import re, unicodedata
from .schema import Box, Invoice, Amount
from .layout import group_lines, line_text
from .numbers import find_amounts

def norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return s.lower()

def _cx(b): return (b.x0 + b.x1) / 2
def _conf(boxes): return min((b.conf for b in boxes), default=1.0)

# ---- keyword rules for totals: first match wins, so order matters -------------
RULES = [
    ("net_a_payer", r"net\s*a\s*payer|montant\s*a\s*payer|net\s*payer"),
    ("ttc",         r"\bttc\b|toutes\s*taxes"),
    ("timbre",      r"timbre"),
    ("tva19",       r"tva[^0-9a-z]{0,6}19\b"),
    ("tva9",        r"tva[^0-9a-z]{0,6}9\b"),
    ("ht19",        r"(ht|base|montant|total|hors)[^0-9]{0,15}\b19\s*%"),
    ("ht9",         r"(ht|base|montant|total|hors)[^0-9]{0,15}\b9\s*%"),
    ("ht_exonere",  r"exon"),
    ("total_tva",   r"\btva\b"),
    ("total_ht",    r"\bh\.?\s?t\b|hors\s*taxe"),
]
RATE_ROW = re.compile(r"^\W*(19|9)\s*%")

def _rule_for(text):
    t = norm(text)
    for name, pat in RULES:
        if re.search(pat, t): return name
    return None

def _line_segments(line):
    """Split a visual line into (prefix boxes, [segment, ...]); a segment starts at a label box.
    Needed because several tables often share the same visual line."""
    prefix, segs = [], []
    for b in line:
        if _rule_for(b.text): segs.append([b])
        elif segs: segs[-1].append(b)
        else: prefix.append(b)
    return prefix, segs

def _next_line_amount(lines, i):
    """Label stands alone on its line, value is alone on the next one."""
    if i + 1 >= len(lines): return None
    nl = lines[i + 1]
    if len(nl) > 2 or any(_rule_for(b.text) for b in nl): return None
    am = find_amounts(line_text(nl))
    return am[-1] if am else None

# ---- VAT breakdown table (Taux | Base | Montant TVA, in any column order) ------
RATE_BOX = re.compile(r"^(taux|taux\s*tva|tva\s*%|%\s*tva)$")
TVA_COL = re.compile(r"^(montant\s*tva|total\s*tva|tva)$")
HT_COL = re.compile(r"^(base|base\s*h\.?t|total\s*h\.?t|montant\s*h\.?t)$")
RATE_VAL = re.compile(r"^(\d{1,2})(?:[.,]0+)?\s*%?$")

def _clean(b): return norm(b.text).strip(" :")

def _rate_table(lines) -> dict:
    out = {}
    for i, ln in enumerate(lines):
        rates = [b for b in ln if RATE_BOX.match(_clean(b))]
        tvas = [b for b in ln if TVA_COL.match(_clean(b))]
        hts = [b for b in ln if HT_COL.match(_clean(b))]
        if not (rates and tvas and hts): continue
        r0 = min(rates, key=lambda b: b.x0)
        tvas = [b for b in tvas if b.x0 > r0.x0]; hts = [b for b in hts if b.x0 > r0.x0]
        if not (tvas and hts): continue
        tv = min(tvas, key=lambda b: b.x0)
        ht = min(hts, key=lambda b: abs(_cx(b) - _cx(tv)))
        xmin, xmax = r0.x0 - 40, max(tv.x1, ht.x1) + 25
        for ln2 in lines[i + 1:i + 6]:
            cells = [b for b in ln2 if xmin <= _cx(b) <= xmax]
            m = RATE_VAL.match(norm(cells[0].text).strip()) if cells else None
            if not m: break
            nums = [(b, a[-1]) for b in cells[1:] if (a := find_amounts(b.text))]
            if len(nums) < 2: break
            tva_b = min(nums, key=lambda x: abs(_cx(x[0]) - _cx(tv)))
            ht_b = min(nums, key=lambda x: abs(_cx(x[0]) - _cx(ht)))
            r = m.group(1)
            if tva_b is not ht_b and r in ("19", "9"):
                out[f"ht{r}"] = Amount(ht_b[1][0], ht_b[1][1], ht_b[0].conf)
                out[f"tva{r}"] = Amount(tva_b[1][0], tva_b[1][1], tva_b[0].conf)
        if out: break
    return out

def extract_totals(lines) -> dict:
    explicit: dict[str, Amount] = {}
    table = _rate_table(lines)
    for i, ln in enumerate(lines):
        prefix, segs = _line_segments(ln)
        m = RATE_ROW.match(norm(line_text(prefix)))          # text style: "19 %  base  tva"
        if m:
            am = find_amounts(line_text(prefix))
            if len(am) >= 2:
                r = m.group(1)
                table.setdefault(f"ht{r}", Amount(am[0][0], am[0][1], _conf(prefix)))
                table.setdefault(f"tva{r}", Amount(am[1][0], am[1][1], _conf(prefix)))
        for si, seg in enumerate(segs):
            text = line_text(seg)
            name = _rule_for(text)
            am = find_amounts(text)
            best = am[-1] if am else None
            if not best and si == len(segs) - 1 and not find_amounts(line_text(ln)):
                best = _next_line_amount(lines, i)
            if name and best:                      # later (lower on page) match overrides earlier
                explicit[name] = Amount(best[0], best[1], _conf(seg))
    return {**table, **explicit}                   # explicit labels beat table parsing

# ---- header ----------------------------------------------------------------
DATE_RE = re.compile(r"(?<!\d)(\d{1,2})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{4}|\d{2})(?!\d)")
NUM_RE = re.compile(r"(?:facture|fact\.?|invoice)\s*(?:n[o°]?\.?|num\w*|:|-)?\s*[:\-]?\s*([a-z0-9][a-z0-9/_.\-]*)")
NUM_NEXT = re.compile(r"^\W*n\s*[°o]\s*[:\-]?\s*(\S*\d\S*)")      # 'Facture' / 'N° 190/26' on two lines
_NUMS = r"\s*[:\-°]?\s*([\do\s]{12,25})"
NIF_RE = re.compile(r"(?:\bn\.?\s?i\.?\s?f\b|immatriculation\s+fiscale|imm\.?\s*fisc\w*)\.?" + _NUMS)
NIS_RE = re.compile(r"(?:\bn\.?\s?i\.?\s?s\b|identification\s+statistique)\.?" + _NUMS)
ART_RE = re.compile(r"(?:\bart\b\.?(?:\s*imp\w*)?|article\s+d.imposition)\s*[:\-°]?\s*(\d[\d\s]{6,14})"
                    r"|\ba[il1]\b\s*[:\-]\s*(\d[\d\s]{6,14})")
LEGAL_RE = re.compile(r"^\W*(ets|etablissements?|entreprise)\b|\b(sarl|eurl|spa|snc|scs|sas)\b")
CLIENT_BOX = re.compile(r"^\W*client\s*:?\s*(.*)$", re.I)

def _digits(s):  # OCR often reads 0 as O
    return re.sub(r"\D", "", s.lower().replace("o", "0"))

def _iso(d, m, y):
    d, m, y = int(d), int(m), int(y)
    if y < 100: y += 2000
    if not (1 <= d <= 31 and 1 <= m <= 12): return None
    return f"{y:04d}-{m:02d}-{d:02d}"

def _legal_names(lines):
    """Boxes holding a company name. A lone 'SARL' (logo) is joined with the box right above it."""
    flat = [b for ln in lines for b in ln]
    names = []
    for i, ln in enumerate(lines):
        for b in ln:
            if not LEGAL_RE.search(norm(b.text)): continue
            if len(b.text.split()) >= 2:
                names.append((i, b.text.strip())); continue
            above = [a for a in flat if a is not b and a.y1 <= b.y0 + 0.5 * b.h
                     and b.y0 - a.y1 < 1.2 * b.h and min(a.x1, b.x1) - max(a.x0, b.x0) > 0.2 * (b.x1 - b.x0)]
            if above:
                a = max(above, key=lambda a: a.y1)
                names.append((i, f"{a.text.strip()} {b.text.strip()}"))
    return names

_NOT_NAME = re.compile(r"\b(facture|page|date|client|tel|fax|capital|banque|rc|nif|nis|invoice|adresse|email|article)\b")

def _guess_name(lines, upto):
    """Fallback: the tallest 'plain' text above the supplier's NIF line (usually the company title)."""
    best = None
    for ln in lines[:max(upto, 1)]:
        for b in ln:
            t = b.text.strip()
            if len(t) < 4 or sum(c.isalpha() for c in t) / len(t) < 0.6: continue
            if ":" in t or "°" in t or _NOT_NAME.search(norm(t)): continue
            if best is None or b.h > best.h: best = b
    return best.text.strip() if best else None

def extract_header(lines) -> dict:
    out = {"date": None, "number": None, "nifs": [], "nis": [], "arts": [], "names": [], "clients": [], "nif_line": {}}
    texts = [norm(line_text(l)) for l in lines]
    for t in texts:                                   # date: prefer a line mentioning 'date'
        if "date" in t:
            m = DATE_RE.search(t)
            if m and (iso := _iso(*m.groups())): out["date"] = iso; break
    if not out["date"]:
        for t in texts:
            m = DATE_RE.search(t)
            if m and (iso := _iso(*m.groups())): out["date"] = iso; break
    for t in texts:                                   # invoice number on the 'Facture' line
        m = NUM_RE.search(t)
        if m and re.search(r"\d", m.group(1)) and not DATE_RE.fullmatch(m.group(1)):
            out["number"] = m.group(1).strip("./-").upper(); break
    if not out["number"]:                             # ... or on the line right after it
        for i, t in enumerate(texts):
            if re.search(r"\bfacture\b", t):
                for t2 in texts[i + 1:i + 3]:
                    m = NUM_NEXT.match(t2)
                    if m: out["number"] = m.group(1).strip("./-").upper(); break
            if out["number"]: break
    for li, t in enumerate(texts):
        for m in NIF_RE.finditer(t):
            d = _digits(m.group(1))
            if len(d) in (15, 20) and d not in out["nifs"]:
                out["nifs"].append(d); out["nif_line"][d] = li
        for m in NIS_RE.finditer(t):
            d = _digits(m.group(1))
            if len(d) == 15 and d not in out["nis"]: out["nis"].append(d)
        for m in ART_RE.finditer(t):
            d = _digits(m.group(1) or m.group(2))
            if 8 <= len(d) <= 15 and d not in out["arts"]: out["arts"].append(d)
    out["client_line"] = None                         # first 'Client' line: the issuer block is above it
    for li, ln in enumerate(lines):                   # 'Client : NAME' (value in the next box)
        for j, b in enumerate(ln):
            m = CLIENT_BOX.match(b.text)
            if m and "code" not in norm(b.text):
                if out["client_line"] is None: out["client_line"] = li
                name = m.group(1).strip() or (ln[j + 1].text.strip() if j + 1 < len(ln) else "")
                if sum(c.isalpha() for c in name) >= 3 and sum(c.isalpha() for c in name) >= 0.5 * len(name):
                    out["clients"].append(name)       # skips customer codes like 'Client : 0007567269'
    out["names"] = _legal_names(lines)
    return out

def extract_invoice(boxes: list[Box], kind: str = "unknown", own_nif: str | None = None,
                    own_name: str | None = None) -> Invoice:
    """kind: 'purchase' | 'sales' | 'unknown' (auto-detect needs own_nif)."""
    lines = group_lines(boxes)
    inv = Invoice(kind=kind, own_nif=own_nif)
    h = extract_header(lines)
    inv.date, inv.number = h["date"], h["number"]
    nifs = h["nifs"]
    if own_nif:
        others = [n for n in nifs if n != own_nif]
        if kind == "unknown" and own_nif in nifs and nifs:
            inv.kind = "sales" if nifs[0] == own_nif else "purchase"   # issuer is printed first
            inv.notes.append("kind auto-detected from NIF order; confirm")
        inv.counterparty_nif = others[0] if others else None
    elif nifs:
        # issuer's block is printed first: for our own sales the counterparty is the 2nd block
        k = 1 if (kind == "sales" and len(nifs) > 1) else 0
        inv.counterparty_nif = nifs[k]
        if len(nifs) > 1: inv.notes.append("several NIF found; pass own_nif to be sure")
    idx = nifs.index(inv.counterparty_nif) if inv.counterparty_nif in nifs else 0
    # NIS / ART are printed next to their NIF: align by position when the counts match
    pick = lambda lst: (lst[idx] if len(lst) == len(nifs) and len(lst) > idx
                        else (lst[0] if len(lst) == 1 else None))
    inv.counterparty_nis = pick(h["nis"])
    inv.counterparty_art = pick(h["arts"])
    clients = h["clients"]
    if inv.kind == "sales" and clients:
        inv.counterparty_name = clients[0]                  # 'Client : NAME' block
    else:                                                    # supplier = a company name that is not the client
        skip = [norm(x) for x in clients + ([own_name] if own_name else [])]
        cands = [n for i, n in h["names"]
                 if (h["client_line"] is None or i < h["client_line"])
                 and not any(s and (s in norm(n) or norm(n) in s) for s in skip)]
        inv.counterparty_name = cands[0] if cands else None
        if not cands:
            upto = h["nif_line"].get(inv.counterparty_nif, max(len(lines) // 3, 1))
            g = _guess_name(lines, upto)
            if g and not any(norm(g) == s for s in skip):
                inv.counterparty_name = g
                inv.notes.append("supplier name guessed from the largest header text; please confirm")
            else:
                inv.notes.append("supplier name not found")
    inv.amounts = extract_totals(lines)
    return inv
