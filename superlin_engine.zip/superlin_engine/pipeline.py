"""One call: image -> Invoice (extracted, reconciled) + warnings."""
from .ocr_engine import run_ocr
from .extractor import extract_invoice
from .reconcile import reconcile, fiscal_warnings

def process_image(path, kind="unknown", own_nif=None, own_name=None, month=None):
    inv = reconcile(extract_invoice(run_ocr(path), kind, own_nif, own_name))
    return inv, fiscal_warnings(inv, month)
