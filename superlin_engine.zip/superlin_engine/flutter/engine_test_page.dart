import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'engine_service.dart';

class EngineTestController extends GetxController {
  final svc = EngineService();                 // change baseUrl for the tunnel
  final kind = 'purchase'.obs;
  final ownNif = ''.obs;
  final loading = false.obs;
  final result = Rxn<Map<String, dynamic>>();
  final error = ''.obs;

  Future<void> pickAndExtract() async {
    final f = await FilePicker.platform.pickFiles(type: FileType.image);
    if (f == null || f.files.single.path == null) return;
    loading.value = true; error.value = ''; result.value = null;
    try {
      result.value = await svc.extract(File(f.files.single.path!),
          kind: kind.value, ownNif: ownNif.value.isEmpty ? null : ownNif.value);
    } catch (e) { error.value = '$e'; }
    loading.value = false;
  }
}

class EngineTestPage extends StatelessWidget {
  const EngineTestPage({super.key});
  @override
  Widget build(BuildContext context) {
    final c = Get.put(EngineTestController());
    return Scaffold(
      appBar: AppBar(title: const Text('Engine test')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Obx(() => SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'purchase', label: Text('Purchase')),
                  ButtonSegment(value: 'sales', label: Text('Sales')),
                ],
                selected: {c.kind.value},
                onSelectionChanged: (s) => c.kind.value = s.first)),
          const SizedBox(height: 8),
          TextField(
              decoration: const InputDecoration(labelText: 'Company NIF'),
              onChanged: (v) => c.ownNif.value = v),
          const SizedBox(height: 8),
          ElevatedButton.icon(
              onPressed: c.pickAndExtract,
              icon: const Icon(Icons.document_scanner), label: const Text('Pick invoice & extract')),
          const SizedBox(height: 12),
          Expanded(child: Obx(() {
            if (c.loading.value) return const Center(child: CircularProgressIndicator());
            if (c.error.value.isNotEmpty) return SelectableText(c.error.value);
            final r = c.result.value;
            if (r == null) return const Text('No result yet');
            return SingleChildScrollView(
                child: SelectableText(const JsonEncoder.withIndent('  ').convert(r)));
          })),
        ]),
      ),
    );
  }
}
