// pubspec.yaml: http: ^1.2.0, file_picker: ^8.0.0, get: ^4.6.6
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class EngineService {
  EngineService({this.baseUrl = 'http://127.0.0.1:8000', this.apiKey});
  final String baseUrl;       // local server, or your Cloudflare tunnel URL
  final String? apiKey;

  Map<String, String> get _headers => {if (apiKey != null) 'x-api-key': apiKey!};

  Future<Map<String, dynamic>> extract(File image,
      {required String kind, String? ownNif, String? ownName, String? month}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/extract'))
      ..headers.addAll(_headers)
      ..fields['kind'] = kind                       // 'purchase' | 'sales'
      ..files.add(await http.MultipartFile.fromPath('file', image.path));
    if (ownNif != null) req.fields['own_nif'] = ownNif;
    if (ownName != null) req.fields['own_name'] = ownName;
    if (month != null) req.fields['month'] = month; // '2026-11'
    final res = await http.Response.fromStream(
        await req.send().timeout(const Duration(seconds: 120)));
    if (res.statusCode != 200) throw Exception('Engine ${res.statusCode}: ${res.body}');
    return jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
  }

  Future<List<dynamic>> entry(Map<String, dynamic> invoice, {Map<String, String>? accounts}) async {
    final res = await http.post(Uri.parse('$baseUrl/entry'),
        headers: {..._headers, 'content-type': 'application/json'},
        body: jsonEncode({'invoice': invoice, 'accounts': accounts}));
    if (res.statusCode != 200) throw Exception(res.body);
    return jsonDecode(res.body) as List<dynamic>;
  }

  Future<Map<String, dynamic>> g50(List<Map<String, dynamic>> invoices) async {
    final res = await http.post(Uri.parse('$baseUrl/g50'),
        headers: {..._headers, 'content-type': 'application/json'},
        body: jsonEncode({'invoices': invoices}));
    if (res.statusCode != 200) throw Exception(res.body);
    return jsonDecode(res.body) as Map<String, dynamic>;
  }
}
