"""FastAPI server around the SUPERLIN engine.  Run:  uvicorn superlin_engine.server:app --port 8000"""
import os, tempfile
from decimal import Decimal
from typing import Optional
from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Header
from pydantic import BaseModel
from . import ocr_engine
from .extractor import extract_invoice
from .reconcile import reconcile, fiscal_warnings
from .accounting import make_entry, g50_summary
from .schema import Invoice, Amount

API_KEY = os.environ.get("SUPERLIN_API_KEY")      # optional: set it when exposed via a tunnel
app = FastAPI(title="SUPERLIN engine", version="0.1")

def _auth(key):
    if API_KEY and key != API_KEY:
        raise HTTPException(401, "bad api key")

def invoice_to_dict(inv: Invoice) -> dict:
    return {
        "kind": inv.kind, "date": inv.date, "number": inv.number,
        "counterparty_name": inv.counterparty_name,
        "counterparty_nif": inv.counterparty_nif, "counterparty_nis": inv.counterparty_nis,
        "counterparty_art": inv.counterparty_art,
        "amounts": {k: {"value": str(a.value), "conf": round(a.conf, 3), "source": a.source}
                    for k, a in inv.amounts.items()},
        "status": inv.status, "notes": inv.notes,
    }

def dict_to_invoice(d: dict) -> Invoice:
    inv = Invoice(kind=d["kind"], date=d.get("date"), number=d.get("number"),
                  counterparty_name=d.get("counterparty_name"),
                  counterparty_nif=d.get("counterparty_nif"))
    inv.amounts = {k: Amount(Decimal(str(v["value"]))) for k, v in d.get("amounts", {}).items()}
    return inv

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/extract")
async def extract(file: UploadFile = File(...), kind: str = Form("unknown"),
                  own_nif: Optional[str] = Form(None), own_name: Optional[str] = Form(None),
                  month: Optional[str] = Form(None), x_api_key: Optional[str] = Header(None)):
    _auth(x_api_key)
    if kind not in ("purchase", "sales", "unknown"):
        raise HTTPException(400, "kind must be purchase | sales | unknown")
    suffix = os.path.splitext(file.filename or "")[1] or ".jpg"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(await file.read()); path = tmp.name
    try:
        boxes = ocr_engine.run_ocr(path)
    finally:
        os.unlink(path)
    inv = reconcile(extract_invoice(boxes, kind, own_nif, own_name))
    out = invoice_to_dict(inv)
    out["warnings"] = fiscal_warnings(inv, month)
    out["ocr_boxes"] = len(boxes)
    return out

class EntryReq(BaseModel):
    invoice: dict
    accounts: Optional[dict] = None

@app.post("/entry")
def entry(req: EntryReq, x_api_key: Optional[str] = Header(None)):
    """Build the accounting entry from the (user-confirmed) invoice JSON."""
    _auth(x_api_key)
    try:
        rows = make_entry(dict_to_invoice(req.invoice), req.accounts)
    except ValueError as e:
        raise HTTPException(422, str(e))
    return [{**r, "debit": str(r["debit"]), "credit": str(r["credit"])} for r in rows]

class G50Req(BaseModel):
    invoices: list[dict]

@app.post("/g50")
def g50(req: G50Req, x_api_key: Optional[str] = Header(None)):
    _auth(x_api_key)
    s = g50_summary([dict_to_invoice(i) for i in req.invoices])
    return {k: str(v) for k, v in s.items()}
